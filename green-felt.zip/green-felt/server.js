'use strict';
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const E=require('./engine');
const PORT=Number(process.env.PORT||4174),HOST=process.env.HOST||'0.0.0.0',ROOT=path.join(__dirname,'public'),DATA=process.env.GF_DATA_DIR||path.join(__dirname,'data');
const OFFLINE_GRACE_MS=Number(process.env.OFFLINE_GRACE_MS||8000);
fs.mkdirSync(DATA,{recursive:true});const file=path.join(DATA,'store.json');
const loaded=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):{};
const store={sessions:loaded.sessions||{},scores:loaded.scores||{},settled:loaded.settled||{},roomScores:loaded.roomScores||{}};
function save(){const temp=file+'.tmp';fs.writeFileSync(temp,JSON.stringify(store,null,2));fs.renameSync(temp,file);}
const rooms=new Map(),streams=new Map();
const json=(res,status,data)=>{res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(data));};
function body(req){return new Promise((resolve,reject)=>{let raw='';req.on('data',c=>{raw+=c;if(raw.length>8192){reject(Error('请求体过大'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(raw||'{}'));}catch{reject(Error('JSON格式错误'));}});req.on('error',reject);});}
const tokenOf=req=>(req.headers.authorization||'').replace(/^Bearer /,'');
const identity=t=>store.sessions[t];
const codeOf=c=>String(c||'').trim().toUpperCase();
function getRoom(code,s){const r=rooms.get(codeOf(code));if(!r||!s||!r.players.has(s.id))throw Error('房间不存在或你尚未加入');return r;}
function activeRoom(s){return [...rooms.values()].find(r=>r.players.has(s.id));}
function online(id){return (streams.get(id)?.size||0)>0;}
function roomBoard(r){store.roomScores[r.code] ||= {};return store.roomScores[r.code];}
function leaderboard(r){return Object.values(roomBoard(r)).sort((a,b)=>b.score-a.score||b.wins-a.wins||a.name.localeCompare(b.name));}
function addOfflineTimer(r,id){clearTimeout(r.offlineTimers.get(id));const timer=setTimeout(()=>{if(r.hand?.status==='playing'&&!online(id)){const p=r.hand.players.find(x=>x.id===id);endTable(r,`${p?.name||'玩家'} 离线，本桌游戏结束`);}},OFFLINE_GRACE_MS);timer.unref?.();r.offlineTimers.set(id,timer);}
function clearOfflineTimer(r,id){clearTimeout(r.offlineTimers.get(id));r.offlineTimers.delete(id);}
function isEligibleForNextHand(r){return !r.tableEnded&&r.players.size>=2&&[...r.players.values()].every(p=>p.stack>=20&&online(p.id));}
function endTable(r,reason){clearTimeout(r.timer);r.timer=null;r.tableEnded=true;r.endReason=reason;r.deadline=0;if(r.hand&&r.hand.status!=='table-ended'){r.hand.status='table-ended';r.hand.turn=-1;r.hand.result=(r.hand.result?`${r.hand.result}；`:'')+reason;}r.log.unshift(reason);broadcast(r);}
function state(r,s){
 if(r.hand){r.hand.players.forEach(p=>p.connected=online(p.id));return {...E.publicState(r.hand,s.id),code:r.code,hostId:r.hostId,you:s.id,deadline:r.deadline,tableEnded:!!r.tableEnded,endReason:r.endReason||'',canContinue:isEligibleForNextHand(r),leaderboard:leaderboard(r),ranked:true};}
 return {code:r.code,hostId:r.hostId,you:s.id,hand:'',version:0,status:r.tableEnded?'table-ended':'waiting',street:0,board:[],pot:0,button:r.button,turn:-1,deadline:0,bet:0,minRaise:20,log:r.log,result:r.endReason||'',tableEnded:!!r.tableEnded,endReason:r.endReason||'',canContinue:isEligibleForNextHand(r),leaderboard:leaderboard(r),players:[...r.players.values()].map(p=>({...p,bet:0,total:0,folded:false,allin:false,connected:online(p.id),cards:null})),legal:{canAct:false,call:0,minRaiseTo:40,maxRaiseTo:0,canRaise:false,canAllIn:false},ranked:true};
}
function broadcast(r){for(const p of r.players.values())for(const stream of streams.get(p.id)||[])if(stream.code===r.code&&!stream.res.destroyed)stream.res.write('data: '+JSON.stringify(state(r,p))+'\n\n');}
function settle(r){
 const h=r.hand;if(!h||h.status!=='finished'||r.settledHand===h.id)return;
 const board=roomBoard(r);
 for(const p of h.players){const delta=p.stack-p.startStack;const score=board[p.id]||{id:p.id,name:p.name,score:0,roundScore:0,hands:0,wins:0};score.name=p.name;score.score+=delta;score.roundScore=delta;score.hands+=1;if(delta>0)score.wins+=1;board[p.id]=score;}
 r.settledHand=h.id;save();for(const p of h.players){const roomPlayer=r.players.get(p.id);if(roomPlayer)roomPlayer.stack=p.stack;}
}
function resetRoundScores(r){const board=roomBoard(r);Object.values(board).forEach(x=>{x.roundScore=0;});save();}
function finishAfterHand(r){if(r.hand?.status!=='finished')return;settle(r);const depleted=r.hand.players.find(p=>p.stack<20);const offline=r.hand.players.find(p=>!online(p.id));if(depleted)endTable(r,`${depleted.name} 筹码已用完，本桌游戏结束`);else if(offline)endTable(r,`${offline.name} 已离线，本桌游戏结束`);else broadcast(r);}
function schedule(r){clearTimeout(r.timer);r.deadline=0;if(r.hand?.status==='playing'){r.deadline=Date.now()+30000;r.timer=setTimeout(()=>{const h=r.hand;if(h.status!=='playing')return;const p=h.players[h.turn];if(!p)return;const type=p.bet<h.bet?'fold':'check';h.log.unshift(`${p.name} 超时，自动${type==='fold'?'弃牌':'过牌'}`);try{E.act(h,p.id,type);}catch(e){endTable(r,`${p.name} 超时，本桌游戏结束`);return;}finishAfterHand(r);schedule(r);broadcast(r);},30000);r.timer.unref?.();}}
function start(r){
 if(r.tableEnded)throw Error(`本桌已结束：${r.endReason||'请创建新房间'}`);
 if(r.hand?.status==='playing')throw Error('当前牌局尚未结束');
 if(r.hand?.status==='finished'){settle(r);if(!isEligibleForNextHand(r)){const depleted=r.hand.players.find(p=>p.stack<20);const offline=r.hand.players.find(p=>!online(p.id));endTable(r,depleted?`${depleted.name} 筹码已用完，本桌游戏结束`:`${offline?.name||'玩家'} 已离线，本桌游戏结束`);throw Error(r.endReason);}resetRoundScores(r);}
 if(r.players.size<2||r.players.size>5)throw Error('需要2–5位玩家');for(const p of r.players.values())if(p.stack<20)throw Error(p.name+' 筹码不足20，本桌无法继续');
 r.button=(r.button+1)%r.players.size;r.settledHand=null;r.endReason='';r.hand=E.createHand([...r.players.values()],r.button);r.log.unshift(`新牌局开始：本局积分已清零，房间累计积分继续保留`);schedule(r);broadcast(r);
}
async function handle(req,res,url){try{
 if(url.pathname==='/api/leaderboard'&&req.method==='GET'){const s=identity(tokenOf(req)),r=getRoom(url.searchParams.get('code'),s);return json(res,200,{code:r.code,players:leaderboard(r)});}
 if(url.pathname==='/api/events'&&req.method==='GET'){const s=identity(url.searchParams.get('token'));if(!s)return json(res,401,{error:'请登录'});const r=getRoom(url.searchParams.get('code'),s);clearOfflineTimer(r,s.id);res.writeHead(200,{'content-type':'text/event-stream; charset=utf-8','cache-control':'no-cache','connection':'keep-alive','x-accel-buffering':'no'});const stream={res,code:r.code};if(!streams.has(s.id))streams.set(s.id,new Set());streams.get(s.id).add(stream);broadcast(r);const heartbeat=setInterval(()=>{if(!res.destroyed)res.write(': heartbeat\n\n');},10000);heartbeat.unref?.();res.on('close',()=>{clearInterval(heartbeat);streams.get(s.id)?.delete(stream);broadcast(r);if(r.hand?.status==='playing')addOfflineTimer(r,s.id);});return;}
 const b=req.method==='POST'?await body(req):{};
 if(url.pathname==='/api/session'&&req.method==='POST'){let t=b.token,s=identity(t);if(!s){if(!String(b.name||'').trim())throw Error('请输入昵称');t=crypto.randomBytes(32).toString('hex');s={id:crypto.randomUUID(),name:String(b.name).trim().slice(0,18)};store.sessions[t]=s;save();}return json(res,200,{token:t,...s,room:activeRoom(s)?.code||null});}
 const s=identity(tokenOf(req));if(!s)return json(res,401,{error:'请先设置昵称'});
 if(url.pathname==='/api/state'&&req.method==='GET')return json(res,200,state(getRoom(url.searchParams.get('code'),s),s));
 if(req.method!=='POST')return json(res,405,{error:'方法不支持'});
 if(url.pathname==='/api/create'){if(activeRoom(s))throw Error('请先离开当前房间');let code;do{code=crypto.randomBytes(3).toString('hex').toUpperCase();}while(rooms.has(code));const r={code,hostId:s.id,players:new Map([[s.id,{...s,stack:1000}]]),hand:null,button:-1,log:['虚拟筹码1000；等待第二位玩家加入'],deadline:0,offlineTimers:new Map(),tableEnded:false,endReason:'',settledHand:null};rooms.set(code,r);return json(res,200,{code});}
 if(url.pathname==='/api/join'){const r=rooms.get(codeOf(b.code));if(!r)throw Error('房间不存在');if(r.players.has(s.id))return json(res,200,{code:r.code});if(activeRoom(s))throw Error('请先离开原房间');if(r.tableEnded)throw Error('本桌已结束，请创建新房间');if(r.hand?.status==='playing')throw Error('请等待本局结束再加入');if(r.players.size>=5)throw Error('房间已满');r.players.set(s.id,{...s,stack:1000});r.log.unshift(s.name+' 加入');broadcast(r);return json(res,200,{code:r.code});}
 const r=getRoom(b.code,s);
 if(url.pathname==='/api/start'){if(r.hostId!==s.id)throw Error('只有房主可以开局');start(r);return json(res,200,state(r,s));}
 if(url.pathname==='/api/action'){if(!r.hand||r.hand.id!==b.hand||r.hand.version!==b.version)throw Error('状态已更新，请刷新后操作');if(r.hand.status!=='playing')throw Error('本桌已结束，不能继续行动');E.act(r.hand,s.id,b.type,b.amount);finishAfterHand(r);schedule(r);broadcast(r);return json(res,200,state(r,s));}
 if(url.pathname==='/api/leave'){if(r.hand?.status==='playing')throw Error('当前牌局进行中，请完成本局后离桌');for(const timer of r.offlineTimers.values())clearTimeout(timer);r.offlineTimers.clear();r.players.delete(s.id);r.hand=null;if(r.hostId===s.id)r.hostId=r.players.keys().next().value||'';if(!r.players.size){clearTimeout(r.timer);rooms.delete(r.code);}else broadcast(r);return json(res,200,{ok:true});}
 return json(res,404,{error:'接口不存在'});
}catch(e){if(!res.headersSent)json(res,400,{error:e.message});}}
const files={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/client.js':'client.js','/mobile-fixes.css':'mobile-fixes.css'},types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'};
const server=http.createServer((req,res)=>{const url=new URL(req.url,'http://localhost');if(url.pathname.startsWith('/api/'))return handle(req,res,url);const f=files[url.pathname];if(!f)return json(res,404,{error:'页面不存在'});fs.readFile(path.join(ROOT,f),(err,data)=>{if(err)return json(res,500,{error:'页面文件缺失'});res.writeHead(200,{'content-type':types[path.extname(f)]||'text/plain; charset=utf-8','cache-control':'no-cache','x-content-type-options':'nosniff','referrer-policy':'no-referrer'});res.end(data);});});
if(require.main===module)server.listen(PORT,HOST,()=>console.log(`Green Felt: http://localhost:${PORT} (LAN: use this computer's IPv4 address)`));
module.exports={server,rooms,store};
