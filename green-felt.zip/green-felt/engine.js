'use strict';
const {randomInt,randomUUID}=require('node:crypto');
const ranks='23456789TJQKA', names=['高牌','一对','两对','三条','顺子','同花','葫芦','四条','同花顺'];
function compareScore(a,b){for(let i=0;i<Math.max(a.length,b.length);i++){const d=(a[i]||0)-(b[i]||0);if(d)return d;}return 0;}
// Adapted from the uploaded version: enumerate all five-card combinations.
function scoreFive(cards){
 const v=cards.map(c=>c.v).sort((a,b)=>b-a),counts={};v.forEach(x=>counts[x]=(counts[x]||0)+1);
 const g=Object.keys(counts).map(Number).sort((a,b)=>counts[b]-counts[a]||b-a);
 const flush=cards.every(c=>c.s===cards[0].s),u=[...new Set(v)];
 const straight=u.length===5?(u[0]-u[4]===4?u[0]:u.join(',')==='14,5,4,3,2'?5:0):0;
 if(flush&&straight)return [8,straight];
 if(counts[g[0]]===4)return [7,g[0],g[1]];
 if(counts[g[0]]===3&&counts[g[1]]===2)return [6,g[0],g[1]];
 if(flush)return [5,...v];if(straight)return [4,straight];
 if(counts[g[0]]===3)return [3,g[0],...v.filter(x=>x!==g[0])];
 const pairs=g.filter(x=>counts[x]===2);
 if(pairs.length===2)return [2,...pairs,v.find(x=>!pairs.includes(x))];
 if(pairs.length===1)return [1,pairs[0],...v.filter(x=>x!==pairs[0])];return [0,...v];
}
function bestHand(cards){let best=null;function walk(i,a){if(a.length===5){const s=scoreFive(a);if(!best||compareScore(s,best)>0)best=s;return;}for(let j=i;j<=cards.length-5+a.length;j++)walk(j+1,[...a,cards[j]]);}walk(0,[]);return best;}
function deck(){const d=[];for(const s of 'SHDC')for(let i=0;i<13;i++)d.push({r:ranks[i],s,v:i+2});for(let i=51;i>0;i--){const j=randomInt(i+1);[d[i],d[j]]=[d[j],d[i]];}return d;}
function commit(h,i,n){const p=h.players[i],a=Math.min(n,p.stack);p.stack-=a;p.bet+=a;p.total+=a;h.pot+=a;p.allin=p.stack===0;}
function next(h,from,test){for(let k=1;k<=h.players.length;k++){const i=(from+k)%h.players.length;if(test(h.players[i],i))return i;}return -1;}
function createHand(players,button=0){
 if(players.length<2||players.length>5||players.some(p=>!Number.isSafeInteger(p.stack)||p.stack<20))throw Error('需要2–5位筹码不少于20的玩家');
 const h={id:randomUUID(),version:1,status:'playing',deck:deck(),street:0,board:[],pot:0,bet:20,minRaise:20,button,turn:-1,log:['盲注 10 / 20；虚拟积分模式'],result:'',payouts:[],players:players.map(p=>({...p,startStack:p.stack,bet:0,total:0,folded:false,allin:false,cards:[],lastActBet:null}))};
 for(let k=0;k<2;k++)for(let j=1;j<=players.length;j++)h.players[(button+j)%players.length].cards.push(h.deck.pop());
 const sb=players.length===2?button:(button+1)%players.length,bb=(sb+1)%players.length;
 commit(h,sb,10);commit(h,bb,20);h.sb=sb;h.bb=bb;h.pending=new Set(h.players.map((p,i)=>i).filter(i=>!h.players[i].allin));
 advance(h,bb);return h;
}
function legal(h,i){
 const off={canAct:false,call:0,minRaiseTo:0,maxRaiseTo:0,canRaise:false,canAllIn:false};
 if(h.status!=='playing'||h.turn!==i||i<0)return off;
 const p=h.players[i],owed=Math.max(0,h.bet-p.bet),max=p.bet+p.stack;
 // Short all-ins do not reopen raising until the cumulative increase is a full raise.
 const reopened=p.lastActBet===null||h.bet-p.lastActBet>=h.minRaise;
 const opponents=h.players.some((q,j)=>j!==i&&!q.folded&&!q.allin);
 return {canAct:true,call:Math.min(owed,p.stack),minRaiseTo:h.bet+h.minRaise,maxRaiseTo:max,canRaise:opponents&&reopened&&max>=h.bet+h.minRaise,canAllIn:max<=h.bet||(opponents&&reopened)};
}
function dealStreet(h){h.deck.pop();if(h.street===0)h.board.push(h.deck.pop(),h.deck.pop(),h.deck.pop());else h.board.push(h.deck.pop());h.street++;h.bet=0;h.minRaise=20;h.players.forEach(p=>{p.bet=0;p.lastActBet=null;});h.pending=new Set(h.players.map((p,i)=>i).filter(i=>!h.players[i].folded&&!h.players[i].allin));h.log.unshift(['','翻牌','转牌','河牌'][h.street]);}
function finish(h,fold=false){
 if(h.status==='finished')return;
 const paid=Array(h.players.length).fill(0),parts=[];
 if(fold){const i=h.players.findIndex(p=>!p.folded);paid[i]=h.pot;parts.push(`${h.players[i].name} 收下底池 ${h.pot}（其余玩家弃牌）`);}
 else{
  const levels=[...new Set(h.players.map(p=>p.total).filter(x=>x>0))].sort((a,b)=>a-b);let prev=0;
  for(const level of levels){
   const contributors=h.players.map((p,i)=>i).filter(i=>h.players[i].total>=level),amount=(level-prev)*contributors.length;prev=level;
   if(contributors.length===1){paid[contributors[0]]+=amount;parts.push(`退回未被跟注 ${amount}`);continue;}
   const eligible=contributors.filter(i=>!h.players[i].folded);
   if(!eligible.length){for(const i of contributors)paid[i]+=amount/contributors.length;continue;}
   let best=null,winners=[];
   for(const i of eligible){const s=bestHand([...h.players[i].cards,...h.board]);const c=best?compareScore(s,best):1;if(c>0){best=s;winners=[i];}else if(c===0)winners.push(i);}
   // Odd chips go clockwise from the seat left of the dealer.
   winners.sort((a,b)=>(a-h.button-1+h.players.length)%h.players.length-(b-h.button-1+h.players.length)%h.players.length);
   winners.forEach((i,k)=>paid[i]+=Math.floor(amount/winners.length)+(k<amount%winners.length?1:0));
   parts.push(`${winners.map(i=>h.players[i].name).join('、')}：${names[best[0]]}，分得${amount}`);
  }
 }
 h.players.forEach((p,i)=>p.stack+=paid[i]);h.payouts=paid;h.result=parts.join('；');h.log.unshift(h.result);h.pot=0;h.status='finished';h.turn=-1;h.pending.clear();
}
function advance(h,from){
 if(h.players.filter(p=>!p.folded).length===1){finish(h,true);return;}
 for(const i of h.pending)if(h.players[i].folded||h.players[i].allin)h.pending.delete(i);
 const live=h.players.map((p,i)=>i).filter(i=>!h.players[i].folded&&!h.players[i].allin);
 // A lone player must still answer an outstanding all-in bet before runout.
 if(live.length<=1&&(live.length===0||h.players[live[0]].bet>=h.bet)){while(h.street<3)dealStreet(h);finish(h);return;}
 if(!h.pending.size){if(h.street===3){finish(h);return;}dealStreet(h);h.turn=next(h,h.button,(p,i)=>h.pending.has(i));}
 else h.turn=next(h,from,(p,i)=>h.pending.has(i));
}
function act(h,playerId,type,amount){
 const i=h.players.findIndex(p=>p.id===playerId),l=legal(h,i);if(!l.canAct)throw Error('当前不是你的行动');
 const p=h.players[i],old=h.bet;
 if(type==='fold'){p.folded=true;h.log.unshift(`${p.name} 弃牌`);}
 else if(type==='check'){if(p.bet<h.bet)throw Error('面对下注不能过牌');h.log.unshift(`${p.name} 过牌`);}
 else if(type==='call'){commit(h,i,l.call);h.log.unshift(`${p.name} 跟注 ${l.call}`);}
 else if(type==='raise'||type==='allin'){
  const target=type==='allin'?p.bet+p.stack:amount;
  if(type==='raise'&&(!l.canRaise||!Number.isSafeInteger(target)||target<l.minRaiseTo||target>l.maxRaiseTo))throw Error('加注总额不合法');
  if(type==='allin'&&!l.canAllIn)throw Error('短码全押没有重新开放你的加注权');
  commit(h,i,target-p.bet);
  if(target>old){const increment=target-old;h.bet=target;if(increment>=h.minRaise)h.minRaise=increment;h.players.forEach((q,j)=>{if(j!==i&&!q.folded&&!q.allin&&q.bet<h.bet)h.pending.add(j);});}
  h.log.unshift(`${p.name} ${type==='allin'?'全押至':'加注至'} ${target}`);
 }else throw Error('未知行动');
 p.lastActBet=h.bet;h.pending.delete(i);h.version++;advance(h,i);return h;
}
function publicState(h,viewer){return {hand:h.id,version:h.version,status:h.status,street:h.street,board:h.board,pot:h.pot,button:h.button,turn:h.turn,bet:h.bet,minRaise:h.minRaise,result:h.result,log:h.log.slice(0,20),players:h.players.map(p=>({id:p.id,name:p.name,stack:p.stack,bet:p.bet,total:p.total,folded:p.folded,allin:p.allin,connected:p.connected,cards:p.id===viewer||(h.status==='finished'&&!p.folded&&h.board.length===5)?p.cards:null})),legal:legal(h,h.players.findIndex(p=>p.id===viewer))};}
module.exports={createHand,act,legal,publicState,bestHand,scoreFive,compareScore,finish,handName:s=>names[s[0]],compareHands:(a,b)=>compareScore(bestHand(a),bestHand(b))};
