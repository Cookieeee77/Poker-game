'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
process.env.GF_DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'green-felt-api-'));
const {server}=require('./server');
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
 async function api(route,data,token){const r=await fetch(base+route,{method:data===undefined?'GET':'POST',headers:{'content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},body:data===undefined?undefined:JSON.stringify(data)});return {status:r.status,data:await r.json()};}
 try{
 const a=(await api('/api/session',{name:'Test A'})).data,b=(await api('/api/session',{name:'Test B'})).data;
 const code=(await api('/api/create',{},a.token)).data.code;assert.ok(code);
 assert.equal((await api('/api/join',{code},b.token)).status,200);
 const sse=await fetch(base+'/api/events?code='+code+'&token='+b.token);const reader=sse.body.getReader();const first=await reader.read();assert.match(new TextDecoder().decode(first.value),/data:/);
 let s=(await api('/api/start',{code},a.token)).data;assert.equal(s.players.length,2);assert.equal(s.players[1].cards,null);
 assert.equal((await api('/api/start',{code},a.token)).status,400);
 let actions=0;
 while(s.status==='playing'){
 const player=s.players[s.turn].id===a.id?a:b;const own=(await api('/api/state?code='+code,undefined,player.token)).data;
 const payload={code,hand:own.hand,version:own.version,type:own.legal.call?'call':'check'};
 const r=await api('/api/action',payload,player.token);assert.equal(r.status,200);s=r.data;
 assert.equal((await api('/api/action',payload,player.token)).status,400);assert.ok(++actions<50);
 }
 const rank=(await api('/api/leaderboard')).data.players;assert.equal(rank.length,2);assert.equal(rank.reduce((s,p)=>s+p.score,0),0);assert.ok(rank.every(p=>p.hands===1));
 assert.equal((await api('/api/session',{token:a.token})).data.id,a.id);
 assert.equal((await api('/api/start',{code},a.token)).status,200);
 const saved=JSON.parse(fs.readFileSync(path.join(process.env.GF_DATA_DIR,'store.json'),'utf8'));assert.equal(Object.keys(saved.scores).length,2);
 await reader.cancel();console.log('PASS session, create, join, SSE, private cards, legal roundtrip, stale-action rejection, settlement, persistent leaderboard, next hand. Actions:',actions);
 }finally{server.closeAllConnections();server.close();}
})().catch(e=>{console.error(e);process.exitCode=1;server.closeAllConnections();server.close();});
